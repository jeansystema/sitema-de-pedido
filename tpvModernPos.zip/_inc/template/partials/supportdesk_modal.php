<div class="box-body">
  <div class="alert alert-info text-center">
    <p>For any query just knock us via codecanyon comment box. We will reply you within 1 busuness day. Thank you for choosing us :)</p>
  </div>
  <h4 class="text-center">
    <a href="http://docs.itsolution24.com/pos/2-0">Online Documentation Here &rarr;</a>
  </h4>
</div>
